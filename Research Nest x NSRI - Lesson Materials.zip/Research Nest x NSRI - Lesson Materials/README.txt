RESEARCH NEST x NSRI — LESSON MATERIALS
=======================================

The complete Research Nest research course: 9 lessons that take students
from a first question to a finished, shared research paper.

START HERE
  00 Start Here.pdf ........ cover, contents, how to use the pack, credits
  Teacher Answer Key.pdf ... answers and explanations for every lesson quiz

EACH LESSON FOLDER
  ... - Slides.pdf ............ 16:9 slides, one per page, ready to present
  ... - Presenter Notes.pdf ... every slide with what to say
  ... - Lesson Guide.pdf ...... reading, worked example, printable worksheet
                                for the activity, and the lesson quiz

LESSONS
  1  Choose a Topic
  2  Review the Literature
  3  Find a Research Gap
  4  Develop a Research Question
  5  Design the Study
  6  Collect and Analyse Data
  7  Write the Research Paper (two decks)
  8  Present Your Findings
  9  Publish and Disseminate

ONLINE
  Every lesson is also free at research-nest.com/course, with videos,
  interactive quizzes and certificates. Students can practice reading real
  published papers at research-nest.com/practice.

CREDITS AND USE
  Lesson content, slides, worksheets and quizzes (c) Research Nest, shared
  with NSRI for teaching and study. Linked videos and further reading belong
  to their publishers and are listed in each lesson guide. Slides marked
  "Invented example" or "Simulated data" use made-up examples for teaching.
